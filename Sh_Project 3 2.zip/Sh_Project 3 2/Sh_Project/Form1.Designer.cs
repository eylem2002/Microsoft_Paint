﻿
namespace Sh_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnbold1 = new System.Windows.Forms.Button();
            this.btnbold2 = new System.Windows.Forms.Button();
            this.btnbold3 = new System.Windows.Forms.Button();
            this.box_Colors = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnpurple = new System.Windows.Forms.Button();
            this.btnblack = new System.Windows.Forms.Button();
            this.btnaqua = new System.Windows.Forms.Button();
            this.btnorange = new System.Windows.Forms.Button();
            this.btnpink = new System.Windows.Forms.Button();
            this.btnyellow = new System.Windows.Forms.Button();
            this.btngreen = new System.Windows.Forms.Button();
            this.btnred = new System.Windows.Forms.Button();
            this.btnblue = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDraw_Fill = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miOpenXML = new System.Windows.Forms.ToolStripMenuItem();
            this.miOpenImage = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miSaveImage = new System.Windows.Forms.ToolStripMenuItem();
            this.miSaveXML = new System.Windows.Forms.ToolStripMenuItem();
            this.miNew = new System.Windows.Forms.ToolStripMenuItem();
            this.btneraseer = new System.Windows.Forms.Button();
            this.btnpen = new System.Windows.Forms.Button();
            this.btnmove = new System.Windows.Forms.Button();
            this.btnpast = new System.Windows.Forms.Button();
            this.btncopy = new System.Windows.Forms.Button();
            this.btnResize = new System.Windows.Forms.Button();
            this.btnchangecolor = new System.Windows.Forms.Button();
            this.btnfill = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnselectColor = new System.Windows.Forms.Button();
            this.btnpenta = new System.Windows.Forms.Button();
            this.btnellipse = new System.Windows.Forms.Button();
            this.btnline = new System.Windows.Forms.Button();
            this.btnhexa = new System.Windows.Forms.Button();
            this.btnsquare = new System.Windows.Forms.Button();
            this.btnrightTri = new System.Windows.Forms.Button();
            this.btntri = new System.Windows.Forms.Button();
            this.btnrect = new System.Windows.Forms.Button();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.box_Colors.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(11, 209);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(932, 266);
            this.panel1.TabIndex = 15;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btneraseer);
            this.groupBox5.Controls.Add(this.btnpen);
            this.groupBox5.Location = new System.Drawing.Point(846, 55);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox5.Size = new System.Drawing.Size(116, 74);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tools";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnmove);
            this.groupBox4.Controls.Add(this.btnpast);
            this.groupBox4.Controls.Add(this.btncopy);
            this.groupBox4.Controls.Add(this.btnResize);
            this.groupBox4.Controls.Add(this.btnchangecolor);
            this.groupBox4.Controls.Add(this.btnfill);
            this.groupBox4.Controls.Add(this.btndelete);
            this.groupBox4.Location = new System.Drawing.Point(544, 47);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Size = new System.Drawing.Size(298, 91);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Clip Borad";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnbold1);
            this.groupBox3.Controls.Add(this.btnbold2);
            this.groupBox3.Controls.Add(this.btnbold3);
            this.groupBox3.Location = new System.Drawing.Point(441, 42);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(100, 132);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Size";
            // 
            // btnbold1
            // 
            this.btnbold1.Location = new System.Drawing.Point(8, 83);
            this.btnbold1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnbold1.Name = "btnbold1";
            this.btnbold1.Size = new System.Drawing.Size(76, 25);
            this.btnbold1.TabIndex = 5;
            this.btnbold1.Text = "Bold1";
            this.btnbold1.UseVisualStyleBackColor = true;
            this.btnbold1.Click += new System.EventHandler(this.btnbold1_Click);
            // 
            // btnbold2
            // 
            this.btnbold2.Location = new System.Drawing.Point(8, 53);
            this.btnbold2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnbold2.Name = "btnbold2";
            this.btnbold2.Size = new System.Drawing.Size(76, 25);
            this.btnbold2.TabIndex = 4;
            this.btnbold2.Text = "Bold2";
            this.btnbold2.UseVisualStyleBackColor = true;
            this.btnbold2.Click += new System.EventHandler(this.btnbold2_Click);
            // 
            // btnbold3
            // 
            this.btnbold3.Location = new System.Drawing.Point(8, 25);
            this.btnbold3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnbold3.Name = "btnbold3";
            this.btnbold3.Size = new System.Drawing.Size(76, 25);
            this.btnbold3.TabIndex = 3;
            this.btnbold3.Text = "Bold3";
            this.btnbold3.UseVisualStyleBackColor = true;
            this.btnbold3.Click += new System.EventHandler(this.btnbold3_Click);
            // 
            // box_Colors
            // 
            this.box_Colors.Controls.Add(this.label1);
            this.box_Colors.Controls.Add(this.btnpurple);
            this.box_Colors.Controls.Add(this.btnblack);
            this.box_Colors.Controls.Add(this.btnaqua);
            this.box_Colors.Controls.Add(this.btnorange);
            this.box_Colors.Controls.Add(this.btnpink);
            this.box_Colors.Controls.Add(this.btnyellow);
            this.box_Colors.Controls.Add(this.btngreen);
            this.box_Colors.Controls.Add(this.btnred);
            this.box_Colors.Controls.Add(this.btnblue);
            this.box_Colors.Controls.Add(this.btnselectColor);
            this.box_Colors.Location = new System.Drawing.Point(286, 42);
            this.box_Colors.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.box_Colors.Name = "box_Colors";
            this.box_Colors.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.box_Colors.Size = new System.Drawing.Size(152, 110);
            this.box_Colors.TabIndex = 11;
            this.box_Colors.TabStop = false;
            this.box_Colors.Text = "Colors";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(92, 80);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "edit colors ";
            // 
            // btnpurple
            // 
            this.btnpurple.BackColor = System.Drawing.Color.Purple;
            this.btnpurple.Location = new System.Drawing.Point(68, 76);
            this.btnpurple.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnpurple.Name = "btnpurple";
            this.btnpurple.Size = new System.Drawing.Size(21, 19);
            this.btnpurple.TabIndex = 27;
            this.btnpurple.UseVisualStyleBackColor = false;
            this.btnpurple.Click += new System.EventHandler(this.btnpurple_Click);
            // 
            // btnblack
            // 
            this.btnblack.BackColor = System.Drawing.Color.Black;
            this.btnblack.Location = new System.Drawing.Point(38, 76);
            this.btnblack.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnblack.Name = "btnblack";
            this.btnblack.Size = new System.Drawing.Size(21, 19);
            this.btnblack.TabIndex = 26;
            this.btnblack.UseVisualStyleBackColor = false;
            this.btnblack.Click += new System.EventHandler(this.btnblack_Click);
            // 
            // btnaqua
            // 
            this.btnaqua.BackColor = System.Drawing.Color.Aqua;
            this.btnaqua.Location = new System.Drawing.Point(7, 76);
            this.btnaqua.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnaqua.Name = "btnaqua";
            this.btnaqua.Size = new System.Drawing.Size(21, 19);
            this.btnaqua.TabIndex = 25;
            this.btnaqua.UseVisualStyleBackColor = false;
            this.btnaqua.Click += new System.EventHandler(this.btnaqua_Click);
            // 
            // btnorange
            // 
            this.btnorange.BackColor = System.Drawing.Color.Orange;
            this.btnorange.Location = new System.Drawing.Point(68, 51);
            this.btnorange.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnorange.Name = "btnorange";
            this.btnorange.Size = new System.Drawing.Size(21, 19);
            this.btnorange.TabIndex = 24;
            this.btnorange.UseVisualStyleBackColor = false;
            this.btnorange.Click += new System.EventHandler(this.btnorange_Click);
            // 
            // btnpink
            // 
            this.btnpink.BackColor = System.Drawing.Color.Pink;
            this.btnpink.Location = new System.Drawing.Point(38, 51);
            this.btnpink.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnpink.Name = "btnpink";
            this.btnpink.Size = new System.Drawing.Size(21, 19);
            this.btnpink.TabIndex = 23;
            this.btnpink.UseVisualStyleBackColor = false;
            this.btnpink.Click += new System.EventHandler(this.btnpink_Click);
            // 
            // btnyellow
            // 
            this.btnyellow.BackColor = System.Drawing.Color.Yellow;
            this.btnyellow.Location = new System.Drawing.Point(7, 51);
            this.btnyellow.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnyellow.Name = "btnyellow";
            this.btnyellow.Size = new System.Drawing.Size(21, 19);
            this.btnyellow.TabIndex = 22;
            this.btnyellow.UseVisualStyleBackColor = false;
            this.btnyellow.Click += new System.EventHandler(this.btnyellow_Click);
            // 
            // btngreen
            // 
            this.btngreen.BackColor = System.Drawing.Color.Green;
            this.btngreen.Location = new System.Drawing.Point(68, 22);
            this.btngreen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btngreen.Name = "btngreen";
            this.btngreen.Size = new System.Drawing.Size(21, 19);
            this.btngreen.TabIndex = 21;
            this.btngreen.UseVisualStyleBackColor = false;
            this.btngreen.Click += new System.EventHandler(this.btngreen_Click);
            // 
            // btnred
            // 
            this.btnred.BackColor = System.Drawing.Color.Red;
            this.btnred.Location = new System.Drawing.Point(38, 22);
            this.btnred.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnred.Name = "btnred";
            this.btnred.Size = new System.Drawing.Size(21, 19);
            this.btnred.TabIndex = 20;
            this.btnred.UseVisualStyleBackColor = false;
            this.btnred.Click += new System.EventHandler(this.btnred_Click);
            // 
            // btnblue
            // 
            this.btnblue.BackColor = System.Drawing.Color.Blue;
            this.btnblue.Location = new System.Drawing.Point(7, 22);
            this.btnblue.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnblue.Name = "btnblue";
            this.btnblue.Size = new System.Drawing.Size(21, 19);
            this.btnblue.TabIndex = 19;
            this.btnblue.UseVisualStyleBackColor = false;
            this.btnblue.Click += new System.EventHandler(this.btnblue_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnDraw_Fill);
            this.groupBox1.Controls.Add(this.btnpenta);
            this.groupBox1.Controls.Add(this.btnellipse);
            this.groupBox1.Controls.Add(this.btnline);
            this.groupBox1.Controls.Add(this.btnhexa);
            this.groupBox1.Controls.Add(this.btnsquare);
            this.groupBox1.Controls.Add(this.btnrightTri);
            this.groupBox1.Controls.Add(this.btntri);
            this.groupBox1.Controls.Add(this.btnrect);
            this.groupBox1.Location = new System.Drawing.Point(6, 42);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(284, 162);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shapes";
            // 
            // btnDraw_Fill
            // 
            this.btnDraw_Fill.Location = new System.Drawing.Point(31, 128);
            this.btnDraw_Fill.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDraw_Fill.Name = "btnDraw_Fill";
            this.btnDraw_Fill.Size = new System.Drawing.Size(216, 27);
            this.btnDraw_Fill.TabIndex = 17;
            this.btnDraw_Fill.Text = "Draw_Fill";
            this.btnDraw_Fill.UseVisualStyleBackColor = true;
            this.btnDraw_Fill.Click += new System.EventHandler(this.btnDraw_Fill_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(951, 24);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.miNew});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 22);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miOpenXML,
            this.miOpenImage});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // miOpenXML
            // 
            this.miOpenXML.Name = "miOpenXML";
            this.miOpenXML.Size = new System.Drawing.Size(107, 22);
            this.miOpenXML.Text = "Xml";
            this.miOpenXML.Click += new System.EventHandler(this.miOpenXML_Click);
            // 
            // miOpenImage
            // 
            this.miOpenImage.Name = "miOpenImage";
            this.miOpenImage.Size = new System.Drawing.Size(107, 22);
            this.miOpenImage.Text = "Image";
            this.miOpenImage.Click += new System.EventHandler(this.miOpenImage_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miSaveImage,
            this.miSaveXML});
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.saveAsToolStripMenuItem.Text = "Save As";
            // 
            // miSaveImage
            // 
            this.miSaveImage.Name = "miSaveImage";
            this.miSaveImage.Size = new System.Drawing.Size(107, 22);
            this.miSaveImage.Text = "Image";
            this.miSaveImage.Click += new System.EventHandler(this.miSaveImage_Click);
            // 
            // miSaveXML
            // 
            this.miSaveXML.Name = "miSaveXML";
            this.miSaveXML.Size = new System.Drawing.Size(107, 22);
            this.miSaveXML.Text = "XML";
            this.miSaveXML.Click += new System.EventHandler(this.miSaveXML_Click);
            // 
            // miNew
            // 
            this.miNew.Name = "miNew";
            this.miNew.Size = new System.Drawing.Size(114, 22);
            this.miNew.Text = "New";
            this.miNew.Click += new System.EventHandler(this.miNew_Click);
            // 
            // btneraseer
            // 
            this.btneraseer.BackgroundImage = global::Sh_Project.Properties.Resources.eraser;
            this.btneraseer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btneraseer.Location = new System.Drawing.Point(53, 16);
            this.btneraseer.Margin = new System.Windows.Forms.Padding(2);
            this.btneraseer.Name = "btneraseer";
            this.btneraseer.Size = new System.Drawing.Size(47, 51);
            this.btneraseer.TabIndex = 8;
            this.btneraseer.UseVisualStyleBackColor = true;
            this.btneraseer.Click += new System.EventHandler(this.btneraseer_Click);
            // 
            // btnpen
            // 
            this.btnpen.BackgroundImage = global::Sh_Project.Properties.Resources.attribution_pencil;
            this.btnpen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnpen.Location = new System.Drawing.Point(11, 16);
            this.btnpen.Margin = new System.Windows.Forms.Padding(2);
            this.btnpen.Name = "btnpen";
            this.btnpen.Size = new System.Drawing.Size(38, 51);
            this.btnpen.TabIndex = 7;
            this.btnpen.UseVisualStyleBackColor = true;
            this.btnpen.Click += new System.EventHandler(this.btnpen_Click);
            // 
            // btnmove
            // 
            this.btnmove.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnmove.BackgroundImage")));
            this.btnmove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmove.Location = new System.Drawing.Point(256, 31);
            this.btnmove.Margin = new System.Windows.Forms.Padding(2);
            this.btnmove.Name = "btnmove";
            this.btnmove.Size = new System.Drawing.Size(38, 51);
            this.btnmove.TabIndex = 6;
            this.btnmove.UseVisualStyleBackColor = true;
            this.btnmove.Click += new System.EventHandler(this.btnmove_Click);
            // 
            // btnpast
            // 
            this.btnpast.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnpast.BackgroundImage")));
            this.btnpast.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnpast.Location = new System.Drawing.Point(215, 31);
            this.btnpast.Margin = new System.Windows.Forms.Padding(2);
            this.btnpast.Name = "btnpast";
            this.btnpast.Size = new System.Drawing.Size(38, 51);
            this.btnpast.TabIndex = 5;
            this.btnpast.UseVisualStyleBackColor = true;
            this.btnpast.Click += new System.EventHandler(this.btnpast_Click);
            // 
            // btncopy
            // 
            this.btncopy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncopy.BackgroundImage")));
            this.btncopy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncopy.Location = new System.Drawing.Point(170, 31);
            this.btncopy.Margin = new System.Windows.Forms.Padding(2);
            this.btncopy.Name = "btncopy";
            this.btncopy.Size = new System.Drawing.Size(38, 51);
            this.btncopy.TabIndex = 4;
            this.btncopy.UseVisualStyleBackColor = true;
            this.btncopy.Click += new System.EventHandler(this.btncopy_Click);
            // 
            // btnResize
            // 
            this.btnResize.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnResize.BackgroundImage")));
            this.btnResize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnResize.Location = new System.Drawing.Point(129, 31);
            this.btnResize.Margin = new System.Windows.Forms.Padding(2);
            this.btnResize.Name = "btnResize";
            this.btnResize.Size = new System.Drawing.Size(38, 51);
            this.btnResize.TabIndex = 3;
            this.btnResize.UseVisualStyleBackColor = true;
            this.btnResize.Click += new System.EventHandler(this.btnResize_Click);
            // 
            // btnchangecolor
            // 
            this.btnchangecolor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnchangecolor.BackgroundImage")));
            this.btnchangecolor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnchangecolor.Location = new System.Drawing.Point(88, 31);
            this.btnchangecolor.Margin = new System.Windows.Forms.Padding(2);
            this.btnchangecolor.Name = "btnchangecolor";
            this.btnchangecolor.Size = new System.Drawing.Size(38, 51);
            this.btnchangecolor.TabIndex = 2;
            this.btnchangecolor.UseVisualStyleBackColor = true;
            this.btnchangecolor.Click += new System.EventHandler(this.btnchangecolor_Click);
            // 
            // btnfill
            // 
            this.btnfill.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnfill.BackgroundImage")));
            this.btnfill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnfill.Location = new System.Drawing.Point(48, 31);
            this.btnfill.Margin = new System.Windows.Forms.Padding(2);
            this.btnfill.Name = "btnfill";
            this.btnfill.Size = new System.Drawing.Size(38, 51);
            this.btnfill.TabIndex = 1;
            this.btnfill.UseVisualStyleBackColor = true;
            this.btnfill.Click += new System.EventHandler(this.btnfill_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btndelete.BackgroundImage")));
            this.btndelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndelete.Location = new System.Drawing.Point(8, 31);
            this.btndelete.Margin = new System.Windows.Forms.Padding(2);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(36, 51);
            this.btndelete.TabIndex = 0;
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnselectColor
            // 
            this.btnselectColor.BackgroundImage = global::Sh_Project.Properties.Resources.images;
            this.btnselectColor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnselectColor.Location = new System.Drawing.Point(102, 22);
            this.btnselectColor.Margin = new System.Windows.Forms.Padding(2);
            this.btnselectColor.Name = "btnselectColor";
            this.btnselectColor.Size = new System.Drawing.Size(20, 49);
            this.btnselectColor.TabIndex = 18;
            this.btnselectColor.UseVisualStyleBackColor = true;
            this.btnselectColor.Click += new System.EventHandler(this.btnselectColor_Click);
            // 
            // btnpenta
            // 
            this.btnpenta.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231918;
            this.btnpenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnpenta.Location = new System.Drawing.Point(216, 74);
            this.btnpenta.Margin = new System.Windows.Forms.Padding(2);
            this.btnpenta.Name = "btnpenta";
            this.btnpenta.Size = new System.Drawing.Size(45, 46);
            this.btnpenta.TabIndex = 16;
            this.btnpenta.UseVisualStyleBackColor = true;
            this.btnpenta.Click += new System.EventHandler(this.btnpenta_Click);
            // 
            // btnellipse
            // 
            this.btnellipse.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231617;
            this.btnellipse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnellipse.Location = new System.Drawing.Point(147, 74);
            this.btnellipse.Margin = new System.Windows.Forms.Padding(2);
            this.btnellipse.Name = "btnellipse";
            this.btnellipse.Size = new System.Drawing.Size(45, 46);
            this.btnellipse.TabIndex = 15;
            this.btnellipse.UseVisualStyleBackColor = true;
            this.btnellipse.Click += new System.EventHandler(this.btnellipse_Click);
            // 
            // btnline
            // 
            this.btnline.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231910;
            this.btnline.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnline.Location = new System.Drawing.Point(84, 74);
            this.btnline.Margin = new System.Windows.Forms.Padding(2);
            this.btnline.Name = "btnline";
            this.btnline.Size = new System.Drawing.Size(45, 46);
            this.btnline.TabIndex = 14;
            this.btnline.UseVisualStyleBackColor = true;
            this.btnline.Click += new System.EventHandler(this.btnline_Click);
            // 
            // btnhexa
            // 
            this.btnhexa.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231922;
            this.btnhexa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnhexa.Location = new System.Drawing.Point(22, 74);
            this.btnhexa.Margin = new System.Windows.Forms.Padding(2);
            this.btnhexa.Name = "btnhexa";
            this.btnhexa.Size = new System.Drawing.Size(45, 46);
            this.btnhexa.TabIndex = 13;
            this.btnhexa.UseVisualStyleBackColor = true;
            this.btnhexa.Click += new System.EventHandler(this.btnhexa_Click);
            // 
            // btnsquare
            // 
            this.btnsquare.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231913;
            this.btnsquare.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsquare.Location = new System.Drawing.Point(216, 20);
            this.btnsquare.Margin = new System.Windows.Forms.Padding(2);
            this.btnsquare.Name = "btnsquare";
            this.btnsquare.Size = new System.Drawing.Size(45, 46);
            this.btnsquare.TabIndex = 12;
            this.btnsquare.UseVisualStyleBackColor = true;
            this.btnsquare.Click += new System.EventHandler(this.btndiamond_Click);
            // 
            // btnrightTri
            // 
            this.btnrightTri.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231625;
            this.btnrightTri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrightTri.Location = new System.Drawing.Point(147, 20);
            this.btnrightTri.Margin = new System.Windows.Forms.Padding(2);
            this.btnrightTri.Name = "btnrightTri";
            this.btnrightTri.Size = new System.Drawing.Size(45, 46);
            this.btnrightTri.TabIndex = 11;
            this.btnrightTri.UseVisualStyleBackColor = true;
            this.btnrightTri.Click += new System.EventHandler(this.btnrightTri_Click);
            // 
            // btntri
            // 
            this.btntri.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231637;
            this.btntri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btntri.Location = new System.Drawing.Point(84, 20);
            this.btntri.Margin = new System.Windows.Forms.Padding(2);
            this.btntri.Name = "btntri";
            this.btntri.Size = new System.Drawing.Size(45, 46);
            this.btntri.TabIndex = 10;
            this.btntri.UseVisualStyleBackColor = true;
            this.btntri.Click += new System.EventHandler(this.btntri_Click);
            // 
            // btnrect
            // 
            this.btnrect.BackgroundImage = global::Sh_Project.Properties.Resources.Annotation_2022_12_28_231631;
            this.btnrect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrect.Location = new System.Drawing.Point(22, 20);
            this.btnrect.Margin = new System.Windows.Forms.Padding(2);
            this.btnrect.Name = "btnrect";
            this.btnrect.Size = new System.Drawing.Size(45, 46);
            this.btnrect.TabIndex = 9;
            this.btnrect.UseVisualStyleBackColor = true;
            this.btnrect.Click += new System.EventHandler(this.btnrect_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 509);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.box_Colors);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.box_Colors.ResumeLayout(false);
            this.box_Colors.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btneraseer;
        private System.Windows.Forms.Button btnpen;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnmove;
        private System.Windows.Forms.Button btnpast;
        private System.Windows.Forms.Button btncopy;
        private System.Windows.Forms.Button btnResize;
        private System.Windows.Forms.Button btnchangecolor;
        private System.Windows.Forms.Button btnfill;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnbold1;
        private System.Windows.Forms.Button btnbold2;
        private System.Windows.Forms.Button btnbold3;
        private System.Windows.Forms.GroupBox box_Colors;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnpurple;
        private System.Windows.Forms.Button btnblack;
        private System.Windows.Forms.Button btnaqua;
        private System.Windows.Forms.Button btnorange;
        private System.Windows.Forms.Button btnpink;
        private System.Windows.Forms.Button btnyellow;
        private System.Windows.Forms.Button btngreen;
        private System.Windows.Forms.Button btnred;
        private System.Windows.Forms.Button btnblue;
        private System.Windows.Forms.Button btnselectColor;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDraw_Fill;
        private System.Windows.Forms.Button btnpenta;
        private System.Windows.Forms.Button btnellipse;
        private System.Windows.Forms.Button btnline;
        private System.Windows.Forms.Button btnhexa;
        private System.Windows.Forms.Button btnsquare;
        private System.Windows.Forms.Button btnrightTri;
        private System.Windows.Forms.Button btntri;
        private System.Windows.Forms.Button btnrect;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miOpenXML;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miSaveImage;
        private System.Windows.Forms.ToolStripMenuItem miSaveXML;
        private System.Windows.Forms.ToolStripMenuItem miNew;
        private System.Windows.Forms.ToolStripMenuItem miOpenImage;
    }
}

