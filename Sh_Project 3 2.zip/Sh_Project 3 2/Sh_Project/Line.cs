﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sh_Project
{
    public class Line
    {
        List<Point> points;
        Color color;
        float penSize;
        public Line()
        {
            points = new List<Point>();
        }

        public List<Point> Points { get => points; set => points = value; }
        public Color Color { get => color; set => color = value; }
        public float PenSize { get => penSize; set => penSize = value; }
        public void add(Point p)
        {
            points.Add(p);
        }
    }
}
