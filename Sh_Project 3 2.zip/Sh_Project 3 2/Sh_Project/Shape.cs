﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sh_Project
{
    public enum shapeStyle
    {
        Rectangle,
        Isosceles_Triangle,
        Right_Triangle,
        Diamond,
        Hexagon,
        Line,
        Ellipse,
        Pentagon
    }
    public class Shape
    {
        int x1, x2, y1, y2;
        int width, height;
        Point topleft, lowerRight;
        Color shapeColor;
        float penSize;
        shapeStyle style;
        string draw_fill;

        public int X1 { get => x1; set => x1 = value; }
        public int X2 { get => x2; set => x2 = value; }
        public int Y1 { get => y1; set => y1 = value; }
        public int Y2 { get => y2; set => y2 = value; }
        public int Width { get => width; set => width = value; }
        public int Height { get => height; set => height = value; }
        public Point Topleft { get => topleft; set => topleft = value; }
        public Point LowerRight { get => lowerRight; set => lowerRight = value; }
        public Color ShapeColor { get => shapeColor; set => shapeColor = value; }
        public float PenSize { get => penSize; set => penSize = value; }
        public shapeStyle Style { get => style; set => style = value; }
        public string Draw_fill { get => draw_fill; set => draw_fill = value; }
        public Shape(int x1, int y1, int x2, int y2, shapeStyle t, Color color, float penSize, string df)
        {

            Style = t;
            X1 = x1;
            X2 = x2;
            Y1 = y1;
            Y2 = y2;
            Topleft = new Point(Math.Min(x1, x2), Math.Min(y1, y2));
            LowerRight = new Point(Math.Max(x1, x2), Math.Max(y1, y2));
            Width = Math.Abs(x2 - x1);
            Height = Math.Abs(y2 - y1);
            ShapeColor = color;
            PenSize = penSize;
            Draw_fill = df;

        }
        public Shape() { }
        public void draw(Graphics G,Graphics g2)
        {
            Point[] isoTri = new Point[]
                            {
                                new Point(Topleft.X+(Width/2),Topleft.Y ),
                                new Point (LowerRight.X,LowerRight.Y)
                                , new Point(Topleft.X,LowerRight.Y)

                            };
            Point[] rightTri = new Point[] {new Point(Topleft.X,Topleft.Y ),
                             new Point (LowerRight.X,LowerRight.Y)
                                , new Point(Topleft.X,Topleft.Y+Height)

                            };
            Point[] diamond = new Point[] {new Point(Topleft.X+Width/2,Topleft.Y),
                             new Point (LowerRight.X,Topleft.Y+Height/2)
                                , new Point(Topleft.X+Width/2,LowerRight.Y),
                             new Point(Topleft.X,Topleft.Y+Height/2)

                            };
            Point[] hexagon = new Point[]
                            {
                             new Point(Topleft.X+Width/2,Topleft.Y),
                             new Point (LowerRight.X,Topleft.Y+Height/4),
                             new Point(LowerRight.X,Topleft.Y+(3*Height)/4),
                           new Point(Topleft.X+Width/2,LowerRight.Y),
                             new Point(Topleft.X,Topleft.Y+(3*Height)/4),
                             new Point(Topleft.X,Topleft.Y+Height/4)


                            };
            Point[] pentagon = new Point[] {
                                new Point(Topleft.X+Width/2,Topleft.Y),
                                new Point (LowerRight.X,Topleft.Y+Height/3),
                                new Point(Topleft.X+(3*width)/4,LowerRight.Y),
                                new Point(Topleft.X+Width/4,LowerRight.Y),
                                new Point(Topleft.X,Topleft.Y+Height/3)

                              };

            Pen pen = new Pen(shapeColor, penSize);

            if (Draw_fill.Equals("draw"))
            {
                switch (Style)
                {
                    case shapeStyle.Rectangle:
                        {
                            G.DrawRectangle(pen, Topleft.X, Topleft.Y, Width, Height);
                            g2.DrawRectangle(pen, Topleft.X, Topleft.Y, Width, Height);
                            break;

                        }
                    case shapeStyle.Isosceles_Triangle:
                        {
                            
                            G.DrawPolygon(pen, isoTri);
                            g2.DrawPolygon(pen, isoTri);
                            break;

                        }
                    case shapeStyle.Right_Triangle:
                        {
                            
                            G.DrawPolygon(pen, rightTri);
                            g2.DrawPolygon(pen, rightTri);
                            break;

                        }
                    case shapeStyle.Diamond:
                        {

                            G.DrawPolygon(pen, diamond);
                            g2.DrawPolygon(pen, diamond);
                            break;

                        }
                    case shapeStyle.Hexagon:
                        {

                            G.DrawPolygon(pen, hexagon);
                            g2.DrawPolygon(pen, hexagon);
                            break;

                        }
                    case shapeStyle.Line:
                        {
                           
                            G.DrawLine(pen, Topleft.X, Topleft.Y, LowerRight.X, LowerRight.Y);
                            g2.DrawLine(pen, Topleft.X, Topleft.Y, LowerRight.X, LowerRight.Y);
                            break;

                        }
                    case shapeStyle.Ellipse:
                        {
                            G.DrawEllipse(pen, Topleft.X, Topleft.Y, Width, Height);
                            g2.DrawEllipse(pen, Topleft.X, Topleft.Y, Width, Height);
                            break;

                        }
                    case shapeStyle.Pentagon:
                        {

                            G.DrawPolygon(pen, pentagon);
                            g2.DrawPolygon(pen, pentagon);
                            break;

                        }


                }
            }
            else
            {
                SolidBrush brush = new SolidBrush(shapeColor);
                switch (Style)
                {
                    case shapeStyle.Rectangle:
                        {
                            G.FillRectangle(brush, Topleft.X, Topleft.Y, Width, Height);
                            g2.FillRectangle(brush, Topleft.X, Topleft.Y, Width, Height);
                            break;

                        }
                    case shapeStyle.Isosceles_Triangle:
                        {
                          
                            G.FillPolygon(brush, isoTri);
                            g2.FillPolygon(brush, isoTri);
                            break;

                        }
                    case shapeStyle.Right_Triangle:
                        {
                            
                            G.FillPolygon(brush, rightTri);
                            g2.FillPolygon(brush, rightTri);
                            break;

                        }
                    case shapeStyle.Diamond:
                        {

                            G.FillPolygon(brush, diamond);
                            g2.FillPolygon(brush, diamond);
                            break;



                        }
                    case shapeStyle.Hexagon:
                        {

                            G.FillPolygon(brush, hexagon);
                            g2.FillPolygon(brush, hexagon);
                            break;



                        }
                    case shapeStyle.Line:
                        {
                            G.DrawLine(pen, Topleft.X, Topleft.Y, Width, Height);
                            g2.DrawLine(pen, Topleft.X, Topleft.Y, Width, Height);
                            break;

                        }
                    case shapeStyle.Ellipse:
                        {
                            G.FillEllipse(brush, Topleft.X, Topleft.Y, Width, Height);
                            g2.FillEllipse(brush, Topleft.X, Topleft.Y, Width, Height);
                            break;

                        }
                    case shapeStyle.Pentagon:
                        {

                            G.FillPolygon(brush, pentagon);
                            g2.FillPolygon(brush, pentagon);
                            break;

                        }


                }

            }

        }
        

        public void move(int dx, int dy)
        {

            topleft.X += dx;
            topleft.Y += dy;
            lowerRight.X += dx;
            lowerRight.Y += dy;
            x1 += dx;
            x2 += dx;
            y1 += dy;
            y2 += dy;


        }
        public bool is_inside(Point p)
        {

            if (p.X >= topleft.X && p.X <= lowerRight.X && p.Y >= topleft.Y && p.Y <= lowerRight.Y) return true;
            else return false;
        }
        public void select(Graphics G)
        {
            Pen pen = new Pen(Color.Red, 1);
            G.DrawRectangle(pen, Topleft.X, Topleft.Y, Width, Height);
            G.FillRectangle(new SolidBrush(Color.Blue), Topleft.X+width/2,Topleft.Y, 5, 5);
            G.FillRectangle(new SolidBrush(Color.Blue), LowerRight.X , Topleft.Y+height/2, 5, 5);
            G.FillRectangle(new SolidBrush(Color.Blue), Topleft.X + width / 2, LowerRight.Y, 5, 5);
            G.FillRectangle(new SolidBrush(Color.Blue), Topleft.X, Topleft.Y + height / 2, 5, 5);




        }


        




    }
}
