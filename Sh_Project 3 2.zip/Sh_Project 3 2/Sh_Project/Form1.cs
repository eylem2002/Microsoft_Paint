﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;
using System.Xml;


namespace Sh_Project
{
    public partial class Form1 : Form
    {
        Graphics G, g2;
        Bitmap bmp;
        int x1, y1;
        int x2, y2;
        bool ismove;
        bool iscopy;
        bool ispaste;
        bool ischangecolor;
        bool isfill;
        bool isdelete;
        bool isresize;



        List<Shape> shapes;
        int index = 0;

        shapeStyle style;
        Color color = Color.Black;
        float penSize = 2;
        bool flag;
        string df = "";
        bool isDrawing;
        List<Line> lines = new List<Line>();
        Line line;
        int prevX;
        int prevY;
        bool drawShape = false;
        public static int width;
        public static int height;



        public Form1()
        {
            InitializeComponent();
            flag = true;
            G = panel1.CreateGraphics();
            shapes = new List<Shape>();
            bmp = new Bitmap(this.Width, this.Height);
            g2 = Graphics.FromImage(bmp);
            g2.Clear(Color.White);

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {

            if (!drawShape) { 
            isDrawing = true;
                line = new Line();
                line.Color = color;
                line.PenSize = penSize;
                line.add(e.Location);
                lines.Add(line);
                prevX = e.X;
                prevY = e.Y; 
        }

            x1 = e.X;
            y1 = e.Y;

            for (int i = 0; i < shapes.Count; i++)
            {
                if (isfill || ismove || isresize || iscopy || isdelete || ischangecolor) { 
                if (shapes[i].is_inside(new Point(x1, y1)))
                {
                        shapes[i].select(G);
                       

                        index = i;


                }
                }
            
             }
            
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                isDrawing = false;


                x2 = e.X;
                y2 = e.Y;
                


                int dx = x2 - x1;
                int dy = y2 - y1;
                Shape shape;
                if (flag)
                    df = "draw";
                else
                    df = "brush";
                if (ismove)
                {
                    shapes[index].move(dx, dy);
                    redraw();
                }
                else if (ischangecolor)
                {
                    ColorDialog dlg = new ColorDialog();
                    if (dlg.ShowDialog() == DialogResult.OK)
                    {
                        color = dlg.Color;
                    }
                    shape = new Shape(shapes[index].X1, shapes[index].Y1, shapes[index].X2, shapes[index].Y2,
                        shapes[index].Style, color, shapes[index].PenSize, shapes[index].Draw_fill);
                    shapes.Remove(shapes[index]);
                    shape.draw(G, g2);
                    shapes.Add(shape);
                    redraw();

                }
                else if (isdelete)
                {
                    shapes.Remove(shapes[index]);
                    redraw();

                }
                else if (isfill)
                {
                    shape = new Shape(shapes[index].X1, shapes[index].Y1, shapes[index].X2, shapes[index].Y2,
                       shapes[index].Style, shapes[index].ShapeColor, shapes[index].PenSize, "fill");
                    shapes.Remove(shapes[index]);
                    shape.draw(G, g2);
                    shapes.Add(shape);
                    redraw();
                }
                else if (drawShape)
                {

                    shape = new Shape(x1, y1, x2, y2, style, color, penSize, df);
                    shape.draw(G, g2);
                    shapes.Add(shape);
                }
                else if (iscopy)
                {
                    
                }

                if (ispaste)
                {
                    
                    shape = new Shape(x1, y1, x1 + shapes[index].Width, y2 + shapes[index].Height,
                    shapes[index].Style, shapes[index].ShapeColor, shapes[index].PenSize, shapes[index].Draw_fill);
                    shape.draw(G, g2);
                    shapes.Add(shape);
                    redraw();

                }
                else if (isresize)
                {

                    width = shapes[index].Width;
                    height = shapes[index].Height;
                    Resize form2 = new Resize();
                    form2.ShowDialog();
                    shape = new Shape(shapes[index].X1, shapes[index].Y1, shapes[index].X1 + Program.W1,
                       shapes[index].Y1 + Program.H1, shapes[index].Style, shapes[index].ShapeColor, shapes[index].PenSize, shapes[index].Draw_fill);
                    shapes.Remove(shapes[index]);
                    shape.draw(G, g2);
                    shapes.Add(shape);

                   redraw();


                }
                
                
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
            
            }



        }
        public void redraw()
        {

            G.Clear(Color.White);
            g2.Clear(Color.White);
            foreach (Shape item in shapes)
            {
                item.draw(G,g2);
                

            }
            foreach(Line item in lines)
            {
                List<Point> points = item.Points;
                for(int i = 1; i < points.Count(); i++)
                {
                    G.DrawLine(new Pen(item.Color, item.PenSize), points[i-1].X, points[i - 1].Y, points[i].X, points[i].Y);
                   g2.DrawLine(new Pen(item.Color, item.PenSize), points[i - 1].X, points[i - 1].Y, points[i].X, points[i].Y);

                }
                

            }

        }

        private void btnrect_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Rectangle;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;
        }

        private void btntri_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Isosceles_Triangle;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;



        }

        private void btnrightTri_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Right_Triangle;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;


        }



        private void btndiamond_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Diamond;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;



        }

        private void btnhexa_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Hexagon;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;


        }

        private void btnline_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Line;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;

        }

        private void btnellipse_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Ellipse;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;

        }

        private void btnpenta_Click(object sender, EventArgs e)
        {
            style = shapeStyle.Pentagon;
            isDrawing = false;
            drawShape = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;


        }

        private void btnblue_Click(object sender, EventArgs e)
        {
            color = Color.Blue;
        }

        private void btnred_Click(object sender, EventArgs e)
        {
            color = Color.Red;

        }

        private void btngreen_Click(object sender, EventArgs e)
        {
            color = Color.Green;

        }

        private void btnyellow_Click(object sender, EventArgs e)
        {
            color = Color.Yellow;

        }

        private void btnpink_Click(object sender, EventArgs e)
        {
            color = Color.Pink;

        }

        private void btnorange_Click(object sender, EventArgs e)
        {
            color = Color.Orange;

        }

        private void btnaqua_Click(object sender, EventArgs e)
        {
            color = Color.Aqua;

        }

        private void btnblack_Click(object sender, EventArgs e)
        {
            color = Color.Black;

        }

        private void btnpurple_Click(object sender, EventArgs e)
        {
            color = Color.Purple;

        }

        private void btnbold3_Click(object sender, EventArgs e)
        {
            penSize = 6;
        }

        private void btnbold2_Click(object sender, EventArgs e)
        {
            penSize = 4;

        }

        private void btnbold1_Click(object sender, EventArgs e)
        {
            penSize = 2;

        }

        private void btnselectColor_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                color = dlg.Color;
            }
        }

        private void btnDraw_Fill_Click(object sender, EventArgs e)
        {
            flag = !flag;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            
            if (isDrawing)
            {
                G.DrawLine(new Pen(color, penSize), prevX, prevY, e.X, e.Y);
                g2.DrawLine(new Pen(color, penSize), prevX, prevY, e.X, e.Y);////pek
                prevX = e.X;
                prevY = e.Y;
                line.add(e.Location);

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

            G.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height);

            /*
            G.SmoothingMode = SmoothingMode.AntiAlias;
            foreach (List<Point> line in lines.Where(x => x.Count > 1))
                e.Graphics.DrawLines(new Pen(color, penSize), line.ToArray());*/
            redraw();


            
              
          
        }

        private void btnpen_Click(object sender, EventArgs e)
        {
            //color = Color.Black;
            drawShape = false;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;
        }

        private void btneraseer_Click(object sender, EventArgs e)
        {
            color = panel1.BackColor;
            drawShape = false;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            isdelete = true;
            ismove = false;
            ischangecolor = false;
            
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;
        }

        private void btnfill_Click(object sender, EventArgs e)
        {
            isfill = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            
            iscopy = false;
            ispaste = false;
            isresize = false;

        }

        private void btnchangecolor_Click(object sender, EventArgs e)
        {
            ischangecolor = true;
            
            ismove = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;
        }

        private void btnResize_Click(object sender, EventArgs e)
        {
            isresize = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            
        }

        private void btncopy_Click(object sender, EventArgs e)
        {
            iscopy = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            
            ispaste = false;
            isresize = false;
        }

        private void btnpast_Click(object sender, EventArgs e)
        {
            ispaste = true;
            ismove = false;
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            
            isresize = false;
        }

        private void btnmove_Click(object sender, EventArgs e)
        {
            ismove = true;
            
            ischangecolor = false;
            isdelete = false;
            isfill = false;
            iscopy = false;
            ispaste = false;
            isresize = false;
        }

        private void miOpenImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog opg = new OpenFileDialog();
            if (opg.ShowDialog() == DialogResult.OK)
            {
                bmp = new Bitmap(opg.FileName);
                g2 = Graphics.FromImage(bmp);

                G.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height);
            }
        }

        private void miOpenXML_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Done");
            try
            {

                OpenFileDialog op = new OpenFileDialog();
                op.Filter = "xml|*.xml";

                if (op.ShowDialog() == DialogResult.OK)
                {
                    StreamReader reader = new StreamReader(op.FileName);
                    if (op.FilterIndex == 1)//xml file
                    {

                        XmlSerializer ser = new XmlSerializer(typeof(List<Shape>));


                        shapes.AddRange((List<Shape>)ser.Deserialize(reader));



                        
                        reader.Close();
                    }


                }

            }

            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);

            }


        }

        private void miSaveXML_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog sa = new SaveFileDialog();
                sa.Filter = "Xml|*.xml";
                if (sa.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(sa.FileName);
                    if (sa.FilterIndex == 1)
                    {
                        XmlSerializer xs = new XmlSerializer(typeof(List<Shape>));
                        xs.Serialize(sw, shapes);
                        sw.Close();




                   }


                }
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
            }

        }

        private void miNew_Click(object sender, EventArgs e)
        {
            try
            {
                flag = true;
                if (shapes.Count >= 0)
                    for(int i = 0; i < shapes.Count; i++)
                        shapes.Remove(shapes[i]);
                
                G.Clear(Color.White);
                g2.Clear(Color.White);

                   if(lines.Count>0)
                   for (int i = 0; i <lines.Count; i++)
                       lines.Remove(lines[i]);

                

                panel1.BackColor = Color.White;
                color = Color.Black;



               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
            }
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void miSaveImage_Click(object sender, EventArgs e)
        {
            try {
            SaveFileDialog sv = new SaveFileDialog();
            sv.Filter = "PngImage|*.png";
            if (sv.ShowDialog() == DialogResult.OK)
            {

                if (sv.FilterIndex == 1)
                {
                    bmp.Save(sv.FileName, System.Drawing.Imaging.ImageFormat.Png);
                }


                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
